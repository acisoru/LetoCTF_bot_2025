#include <stdio.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void functions() {
    asm("pop %rax ; ret");
    asm("pop %rdi ; ret");
    asm("pop %rsi ; ret");
    asm("pop %rdx ; ret");
    asm("pop %rcx ; ret");
    asm("pop %r8 ; ret");
    asm("pop %r9 ; ret");
    asm("pop %r15 ;ret");
    asm("movq %rax,(%rdi) ; ret");
    asm("xor %rax,(%rdi); ret");
    asm("xor %rax,(%r15) ; ret");
    asm("syscall ; ret");
    asm("pop %r10; ret");
    asm("movq (%rdi), %rax; ret");
    asm("bswap %rax; ret");
    asm("rol %cl, %rax ; ret");
    asm("ror %cl, %rax ; ret");
    asm("add %rcx, %rax ; ret");
    asm("sub %rcx, %rax ; ret");
    asm("movq (%r15), %rdi; ret");
    asm("movq (%r15), %rsi; ret");
    asm("movq (%r15), %rdx; ret");
    asm("movq (%r15), %rcx; ret");
    asm("movq %r15, %r8; ret");
}

#define FLAG_ADDR 0x1002000
static const char PLAINTEXT[32 + 1] = "LIFE_IS_FLAG._FLAG_IS_SPAGHETTI.";

// глобальная переменная для хранения пути к файлу результата
char *g_result_path = NULL;

// главная проверка: принимает 4 блока по 8 байт, путь берёт из g_result_path
void verify(uint64_t b0, uint64_t b1, uint64_t b2, uint64_t b3)
{
    char buf[33];
    memcpy(buf + 0,  &b0, 8);
    memcpy(buf + 8,  &b1, 8);
    memcpy(buf + 16, &b2, 8);
    memcpy(buf + 24, &b3, 8);
    buf[32] = 0;

    int res = (memcmp(buf, PLAINTEXT, 32) == 0) ? 0 : 1;

    FILE *f = fopen(g_result_path, "w");
    if (f) {
        fprintf(f, "%d\n", res);
        fclose(f);
    }
    exit(res);
}

int main(int argc, char **argv) {
    // Сохраняем путь к файлу результата в глобальную переменную (без malloc)
    g_result_path = (argc > 1 && argv[1]) ? argv[1] : "lic.txt";

    size_t pop_rax = (long) functions + 8;
    size_t pop_rdi = (long) functions + 8 + 2;
    size_t pop_rsi = (long) functions + 8 + 4;
    size_t pop_rdx = (long) functions + 8 + 6;
    size_t pop_rcx = (long) functions + 8 + 8;
    size_t pop_r8 = (long) functions + 8 + 10;
    size_t pop_r9 = (long) functions + 8 + 13;
    size_t pop_r15 = (long) functions + 8 + 16;
    size_t mov_rdi_rax = (long) functions + 8 + 19;
    size_t xor_qrdi_rax = (long) functions + 8 + 23;
    size_t xor_qr15_rax = (long) functions + 8 + 27;
    size_t syscall = (long) functions + 8 + 31;
    size_t pop_r10 = (long) functions + 8 + 34;
    size_t mov_rax_rdi = (long) functions + 8 + 37;
    size_t bswap_rax = (long) functions + 8 + 41;
    size_t rol_rax_cl = (long) functions + 8 + 45;
    size_t ror_rax_cl = (long) functions + 8 + 49;
    size_t add_rax_rcx = (long) functions + 8 + 53;
    size_t sub_rax_rcx = (long) functions + 8 + 57;
    size_t mov_rdi_r15 = (long) functions + 8 + 61;
    size_t mov_rsi_r15 = (long) functions + 8 + 65;
    size_t mov_rdx_r15 = (long) functions + 8 + 69;
    size_t mov_rcx_r15 = (long) functions + 8 + 73;
    size_t mov_r8_r15 = (long) functions + 8 + 77;
    int i = 0;
    size_t buf[5000] = {0x500000};

    // mmap
    buf[i++] = pop_rax;
    buf[i++] = 0x9;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1000000;
    buf[i++] = pop_rsi;
    buf[i++] = 0x4000;
    buf[i++] = pop_rdx;
    buf[i++] = 0x7;
    buf[i++] = pop_r10;
    buf[i++] = 32 | 2;
    buf[i++] = pop_r8;
    buf[i++] = -1;
    buf[i++] = pop_r9;
    buf[i++] = 0;
    buf[i++] = syscall;

    // Open lic.txt
    buf[i++] = pop_rax;
    buf[i++] = 2;  // SYS_open
    buf[i++] = pop_rdi;
    buf[i++] = (size_t) (argc > 1 ? argv[1] : "lic.txt");
    buf[i++] = pop_rsi;
    buf[i++] = O_RDONLY;
    buf[i++] = syscall;

    // Read from lic.txt
    buf[i++] = pop_rdi;
    buf[i++] = 3;
    buf[i++] = pop_rsi;
    buf[i++] = 0x1000000;
    buf[i++] = pop_rdx;
    buf[i++] = 32;
    buf[i++] = pop_rax;
    buf[i++] = 0;
    buf[i++] = syscall;

    // Close lic.txt
    buf[i++] = pop_rdi;
    buf[i++] = 3;
    buf[i++] = pop_rax;
    buf[i++] = 3;
    buf[i++] = syscall;

    // 1 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1001000;
    buf[i++] = pop_rax;
    buf[i++] = 0x00123e2c00002020;
    buf[i++] = xor_qr15_rax;

    // 2 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1001008;
    buf[i++] = pop_rax;
    buf[i++] = 0x31132337551e085c;
    buf[i++] = xor_qr15_rax;

    // 3 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1001010;
    buf[i++] = pop_rax;
    buf[i++] = 0x16216e16252b3226;
    buf[i++] = xor_qr15_rax;

    // 4 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1001018;
    buf[i++] = pop_rax;
    buf[i++] = 0x464f783a07337021;
    buf[i++] = xor_qr15_rax;

    // xor 0-7 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1001000;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1000000;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 8-15 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1001000 + 8;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1000000 + 8;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 16-23 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1001000 + 16;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1000000 + 16;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 24-31 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1001000 + 24;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1000000 + 24;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // 1 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000;
    buf[i++] = pop_rax;
    buf[i++] = 0x321e161e080b0801;
    buf[i++] = xor_qr15_rax;

    // 2 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1002008;
    buf[i++] = pop_rax;
    buf[i++] = 0x0d0a19716600052b;
    buf[i++] = xor_qr15_rax;

    // 3 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1002010;
    buf[i++] = pop_rax;
    buf[i++] = 0x1901001a0d000606;
    buf[i++] = xor_qr15_rax;

    // 4 part of xors
    buf[i++] = pop_r15;
    buf[i++] = 0x1002018;
    buf[i++] = pop_rax;
    buf[i++] = 0x0f681d1a0a1c0606;
    buf[i++] = xor_qr15_rax;

    // xor 0-7 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1001000;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 8-15 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 8;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1001000 + 8;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 16-23 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 16;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1001000 + 16;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // xor 24-31 bytes
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 24;
    buf[i++] = pop_rdi;
    buf[i++] = 0x1001000 + 24;
    buf[i++] = mov_rax_rdi;
    buf[i++] = xor_qr15_rax;

    // Call verify() (теперь без передачи пути к файлу)
    buf[i++] = pop_r15;
    buf[i++] = 0x1002000;
    buf[i++] = mov_rdi_r15;

    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 8;
    buf[i++] = mov_rsi_r15;

    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 16;
    buf[i++] = mov_rdx_r15;

    buf[i++] = pop_r15;
    buf[i++] = 0x1002000 + 24;
    buf[i++] = mov_rcx_r15;

    buf[i++] = (size_t) verify;

    // Start rop
    asm("mov %0, %%rsp" : : "r"(buf));
    asm("ret");
}
