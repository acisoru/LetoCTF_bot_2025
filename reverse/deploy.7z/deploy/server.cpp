#include <QCoreApplication>
#include <QTcpServer>
#include <QTcpSocket>
#include <QTextStream>
#include <QFile>
#include <QDateTime>
#include <QMap>
#include <QHostAddress>
#include <QTemporaryFile>
#include <memory>

// --- DDOS protection: per-IP rate limiting ---
class DdosProtector {
    QMap<QString, qint64> lastRequest;
    const int minIntervalMs = 5000; // 5 секунд между запросами с одного IP

public:
    bool allow(const QHostAddress& addr) {
        QString ip = addr.toString();
        qint64 now = QDateTime::currentMSecsSinceEpoch();
        qint64 last = lastRequest.value(ip, 0);

        if (now - last < minIntervalMs) {
            return false;
        }
        lastRequest[ip] = now;
        return true;
    }
};

class SimpleServer : public QTcpServer {
    DdosProtector ddos;
protected:
    void incomingConnection(qintptr sd) override {
        auto *sock = new QTcpSocket(this);
        sock->setSocketDescriptor(sd);

        // DDOS check
        QHostAddress peer = sock->peerAddress();
        if (!ddos.allow(peer)) {
            sock->write("Too many requests\n");
            sock->disconnectFromHost();
            sock->deleteLater();
            return;
        }

        auto buffer = std::make_shared<QByteArray>();

        connect(sock, &QTcpSocket::readyRead, this, [sock, buffer]() {
            *buffer += sock->readAll();
            if (buffer->size() < 64)
                return;

            const QByteArray plainLP  = buffer->left(32);
            const QByteArray plainLic = buffer->mid(32, 32);
            buffer->clear();

            const QByteArray login    = plainLP.left(16).trimmed();
            const QByteArray password = plainLP.mid(16,16).trimmed();

            QByteArray licBytes = plainLic;
            int zeroPos = licBytes.indexOf('\0');
            if (zeroPos != -1)
                licBytes.truncate(zeroPos);

            QString license = QString::fromUtf8(licBytes);

            static const QByteArray expectedLogin = "TralaleroTralala";
            static const QByteArray expectedPass  = "BalerinaCapucina";
            bool credentialsOk = (login == expectedLogin && password == expectedPass);

            if (!credentialsOk) {
                sock->write("Incorrect\n");
                sock->disconnectFromHost();
                return;
            }

            // --- Проверка лицензии без внешнего процесса ---
            static const QByteArray expectedLicense = "maMMma_m1A_the_pasta_1s_f1gHt1ng";
            bool licenseOk = (license == QString::fromUtf8(expectedLicense));

            if (!licenseOk) {
                sock->write("Incorrect\n");
                sock->disconnectFromHost();
                return;
            }

            // --- Если всё ок, выдаём флаг ---
            QFile flagFile("flag.txt");
            if (flagFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QByteArray flag = flagFile.readAll();
                if (!flag.endsWith('\n'))
                    flag.append('\n'); // Важно: клиент ждёт \n

                sock->write(flag);
                sock->flush();
            } else {
                sock->write("flag error\n");
            }

            sock->disconnectFromHost();
        });

        connect(sock, &QTcpSocket::disconnected, sock, &QTcpSocket::deleteLater);
    }
};

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    SimpleServer srv;
    if (!srv.listen(QHostAddress::AnyIPv4, 8000)) {
        return 1;
    }
    return app.exec();
}