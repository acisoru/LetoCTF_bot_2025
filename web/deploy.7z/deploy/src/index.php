<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPickMeUp - Image Upload Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .upload-form {
            border: 2px dashed #ccc;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
        }
        input[type="file"] {
            margin: 10px 0;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .file-info {
            margin: 20px 0;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🖼️ PHPickMeUp - Image Upload Service</h1>
        <p>Upload your images safely! We validate every image before processing.</p>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
            $uploadDir = 'uploads/';
            
            // Create uploads directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $file = $_FILES['image'];
            $fileName = $file['name'];
            $fileTmp = $file['tmp_name'];
            $fileSize = $file['size'];
            $fileError = $file['error'];
            
            if ($fileError !== UPLOAD_ERR_OK) {
                echo '<div class="alert alert-error">Upload failed with error code: ' . $fileError . '</div>';
            } else {
                // Check file extension
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                
                if (!in_array($fileExtension, $allowedExtensions)) {
                    echo '<div class="alert alert-error">Only JPG, PNG, and GIF files are allowed!</div>';
                } else {
                    // Generate unique filename
                    $uniqueId = uniqid('img_', true);
                    $newFileName = $uniqueId . '.' . $fileExtension;
                    $filePath = $uploadDir . $newFileName;
                    
                    // Move uploaded file
                    if (move_uploaded_file($fileTmp, $filePath)) {
                        // VULNERABLE: Check if file is a valid image using getimagesize()
                        // This creates a TOCTOU vulnerability - time gap between check and use
                        echo '<div class="alert alert-success">File uploaded successfully! Validating image...</div>';
                        
                        // Artificial delay to make TOCTOU exploitation easier
                        sleep(1);
                        
                        $imageInfo = getimagesize($filePath);
                        if ($imageInfo === false) {
                            // Not a valid image, delete it
                            unlink($filePath);
                            echo '<div class="alert alert-error">Invalid image file! File has been removed.</div>';
                        } else {
                            // Valid image, show success message and preview link
                            echo '<div class="alert alert-success">Image validated successfully!</div>';
                            echo '<div class="file-info">';
                            echo '<strong>File ID:</strong> ' . htmlspecialchars($uniqueId) . '<br>';
                            echo '<strong>Type:</strong> ' . htmlspecialchars($imageInfo['mime']) . '<br>';
                            echo '<strong>Dimensions:</strong> ' . $imageInfo[0] . 'x' . $imageInfo[1] . '<br>';
                            echo '<br><a href="view.php?id=' . urlencode($uniqueId) . '" class="btn">👁️ View Image</a>';
                            echo '</div>';
                        }
                    } else {
                        echo '<div class="alert alert-error">Failed to save uploaded file!</div>';
                    }
                }
            }
        }
        ?>
        
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <h3>📎 Upload Your Image</h3>
            <p>Supported formats: JPG, PNG, GIF</p>
            <input type="file" name="image" accept="image/*" required>
            <br><br>
            <button type="submit" class="btn">🚀 Upload Image</button>
        </form>
        
        <div class="file-info">
            <h4>ℹ️ How it works:</h4>
            <ol>
                <li>Upload an image file (JPG, PNG, or GIF)</li>
                <li>Server validates the file using <code>getimagesize()</code></li>
                <li>Valid images are stored and can be viewed</li>
                <li>Invalid files are automatically deleted</li>
            </ol>
        </div>
    </div>
</body>
</html> 