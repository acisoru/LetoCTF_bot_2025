<?php
session_start();

// Get the file ID from URL parameter
$fileId = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($fileId)) {
    die('Error: No file ID specified!');
}

// Sanitize the file ID (basic check)
if (!preg_match('/^img_[a-f0-9.]+$/', $fileId)) {
    die('Error: Invalid file ID format!');
}

$uploadDir = 'uploads/';
$possibleExtensions = ['jpg', 'jpeg', 'png', 'gif'];
$filePath = '';

// Find the file with any allowed extension
foreach ($possibleExtensions as $ext) {
    $testPath = $uploadDir . $fileId . '.' . $ext;
    if (file_exists($testPath)) {
        $filePath = $testPath;
        break;
    }
}

if (empty($filePath)) {
    die('Error: File not found!');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPickMeUp - View Image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .image-container {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .file-info {
            margin: 20px 0;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🖼️ Image Viewer</h1>
        
        <div class="file-info">
            <strong>File ID:</strong> <?php echo htmlspecialchars($fileId); ?><br>
            <strong>File Path:</strong> <?php echo htmlspecialchars($filePath); ?><br>
            <strong>File Size:</strong> <?php echo filesize($filePath); ?> bytes<br>
        </div>
        
        <div class="image-container">
            <h3>📷 Image Preview:</h3>
            <?php
            // VULNERABLE: Include the uploaded file for "image preview template"
            // This is where the LFI vulnerability occurs - if an attacker can replace
            // the image file with PHP code during the TOCTOU window, it will be executed here
            echo "<!-- Including file for image preview template -->\n";
            
            // The vulnerable include - this will execute any PHP code in the file
            include($filePath);
            ?>
        </div>
        
        <a href="index.php" class="btn">⬅️ Back to Upload</a>
        <a href="<?php echo htmlspecialchars($filePath); ?>" class="btn" target="_blank">🔗 Direct Link</a>
    </div>
</body>
</html> 