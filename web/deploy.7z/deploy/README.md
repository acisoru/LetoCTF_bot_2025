# Deploy Instructions

## Quick Start

```bash
docker-compose up --build -d
```

## Service Access

- **Port:** 80 (configurable in docker-compose.yml)
- **URL:** http://localhost:8080 (or server IP)

## Files Structure

- `index.php` - Main upload page with TOCTOU vulnerability
- `view.php` - Image viewer with LFI vulnerability  
- `flag.txt` - Challenge flag (protected by nginx)
- `nginx.conf` - Nginx configuration with security rules
- `supervisord.conf` - Process manager config for nginx + php-fpm
- `Dockerfile` - Container build instructions
- `docker-compose.yml` - Service orchestration
- `src/` - Source files directory
  - `src/index.php` - Main upload source code
  - `src/view.php` - Image viewer source code

## Default Configuration

- **PHP Version:** 7.4-fpm
- **Web Server:** Nginx  
- **Upload Directory:** `/var/www/html/uploads/`
- **Max Upload Size:** 10MB

## Security Notes

- Flag file is protected from direct access
- Uploads directory prevents PHP execution  
- Challenge works through TOCTOU + LFI vulnerabilities

## Troubleshooting

```bash
# Check container logs
docker-compose logs

# Restart services
docker-compose restart

# Rebuild if needed
docker-compose down && docker-compose up --build -d
``` 