#!/bin/bash

echo "=========================================="
echo "PHPickMeUp Challenge - Защищенная версия"
echo "Скрипт развертывания"
echo "=========================================="

# Проверка прав
if [ "$EUID" -eq 0 ]; then
    echo "⚠️  Не запускайте от root, используйте sudo при необходимости"
    exit 1
fi

# Проверка Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker не установлен!"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose не установлен!"
    exit 1
fi

echo "✅ Docker и Docker Compose найдены"

# Остановка старых контейнеров
echo "🛑 Остановка старых контейнеров..."
docker-compose down 2>/dev/null || true

# Удаление старых образов PHPickMeUp
echo "🗑️ Удаление старых образов..."
docker images | grep phpickmeup | awk '{print $3}' | xargs docker rmi -f 2>/dev/null || true

# Сборка и запуск защищенной версии
echo "🔨 Сборка защищенной версии..."
docker-compose up --build -d

# Ожидание запуска
echo "⏳ Ожидание запуска сервисов..."
sleep 10

# Проверка статуса
echo "📊 Проверка статуса..."
if docker ps | grep -q phpickmeup-challenge; then
    echo "✅ Контейнер запущен успешно"
else
    echo "❌ Ошибка запуска контейнера"
    docker logs phpickmeup-challenge --tail 20
    exit 1
fi

# Проверка веб-сервиса
echo "🌐 Проверка веб-сервиса..."
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080 || echo "000")

if [ "$HTTP_STATUS" = "200" ]; then
    echo "✅ Веб-сервис доступен (HTTP 200 OK)"
else
    echo "❌ Веб-сервис недоступен (HTTP $HTTP_STATUS)"
    echo "Логи контейнера:"
    docker logs phpickmeup-challenge --tail 20
    exit 1
fi

# Тест защиты (если есть exploit.py)
if [ -f "exploit.py" ]; then
    echo "🧪 Тестирование базового эксплойта..."
    if python3 exploit.py http://localhost:8080 | grep -q "flag{"; then
        echo "✅ Базовый эксплойт работает"
    else
        echo "⚠️  Базовый эксплойт не сработал (это может быть нормально)"
    fi
fi

echo ""
echo "=========================================="
echo "✅ РАЗВЕРТЫВАНИЕ ЗАВЕРШЕНО УСПЕШНО!"
echo "=========================================="
echo ""
echo "Адрес: http://localhost:8080"
echo "Статус контейнера: docker ps"
echo "Логи: docker logs phpickmeup-challenge"
echo ""
echo "🛡️ ЗАЩИТА АКТИВНА:"
echo "- Автоматическое восстановление файлов"
echo "- Защита от rm -rf команд"
echo "- Резервные копии в /protected/"
echo ""
echo "Для тестирования защиты используйте:"
echo "python3 exploit_mini_test.py http://localhost:8080"
echo "" 