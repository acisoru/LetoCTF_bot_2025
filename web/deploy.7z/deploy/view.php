<?php
session_start();

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// Get the file ID from URL parameter
$fileId = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($fileId)) {
    die('Error: No file ID specified!');
}

// Basic sanitization (but allow the LFI vulnerability for the challenge)
if (!preg_match('/^img_[a-f0-9.]+$/', $fileId)) {
    die('Error: Invalid file ID format!');
}

// Try multiple upload directory paths for the TOCTOU vulnerability
$uploadDirs = ['uploads/', './uploads/', '/tmp/uploads/'];
$possibleExtensions = ['jpg', 'jpeg', 'png', 'gif'];
$filePath = '';
$actualUploadDir = '';

// Find the file with any allowed extension in any possible directory
foreach ($uploadDirs as $uploadDir) {
    if (is_dir($uploadDir)) {
        foreach ($possibleExtensions as $ext) {
            $testPath = $uploadDir . $fileId . '.' . $ext;
            if (file_exists($testPath)) {
                $filePath = $testPath;
                $actualUploadDir = $uploadDir;
                break 2; // Break out of both loops
            }
        }
    }
}

if (empty($filePath)) {
    // Show debug info to help troubleshoot
    echo '<div style="padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 20px;">';
    echo '<h3>File not found debug info:</h3>';
    echo '<strong>Looking for ID:</strong> ' . htmlspecialchars($fileId) . '<br>';
    echo '<strong>Checked directories:</strong><br>';
    foreach ($uploadDirs as $dir) {
        echo '- ' . htmlspecialchars($dir) . ' (exists: ' . (is_dir($dir) ? 'Yes' : 'No') . ')<br>';
        if (is_dir($dir)) {
            echo '&nbsp;&nbsp;Files in directory: ';
            $files = @scandir($dir);
            if ($files) {
                $imgFiles = array_filter($files, function($f) { return strpos($f, 'img_') === 0; });
                echo count($imgFiles) . ' image files<br>';
                if (count($imgFiles) > 0 && count($imgFiles) <= 5) {
                    foreach ($imgFiles as $f) {
                        echo '&nbsp;&nbsp;&nbsp;&nbsp;- ' . htmlspecialchars($f) . '<br>';
                    }
                }
            } else {
                echo 'Cannot read directory<br>';
            }
        }
    }
    echo '</div>';
    die('Error: File not found!');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPickMeUp - View Image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .image-container {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .file-info {
            margin: 20px 0;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🖼️ Image Viewer</h1>
        
        <div class="file-info">
            <strong>File ID:</strong> <?php echo htmlspecialchars($fileId); ?><br>
            <strong>File Path:</strong> <?php echo htmlspecialchars($filePath); ?><br>
            <strong>Upload Directory:</strong> <?php echo htmlspecialchars($actualUploadDir); ?><br>
            <strong>File Size:</strong> <?php echo filesize($filePath); ?> bytes<br>
            <strong>File Permissions:</strong> <?php echo substr(sprintf('%o', fileperms($filePath)), -4); ?><br>
        </div>
        
        <div class="image-container">
            <h3>📷 Image Preview:</h3>
            <?php
            // VULNERABLE: Include the uploaded file for "image preview template"
            // This is where the LFI vulnerability occurs - if an attacker can replace
            // the image file with PHP code during the TOCTOU window, it will be executed here
            echo "<!-- Including file for image preview template -->\n";
            
            // The vulnerable include - this will execute any PHP code in the file
            // However, dangerous PHP functions are now blocked at the PHP level
            include($filePath);
            ?>
        </div>
        
        <a href="index.php" class="btn">⬅️ Back to Upload</a>
        <a href="<?php echo htmlspecialchars($filePath); ?>" class="btn" target="_blank">🔗 Direct Link</a>
    </div>
</body>
</html> 