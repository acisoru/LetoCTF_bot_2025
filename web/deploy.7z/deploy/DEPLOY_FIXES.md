# PHPickMeUp - Fixed Version for Remote Deployment

## 🔧 Fixes Applied

### Problem: File Upload Failures on Remote Server
**Error:** `Failed to save uploaded file!`

### 🛠️ Solutions Implemented:

#### 1. **Enhanced Upload Directory Handling** (`index.php`)
- **Multiple Fallback Directories**: `uploads/`, `./uploads/`, `/tmp/uploads/`
- **Dynamic Directory Creation**: Creates writable directories with 777 permissions
- **Better Permission Management**: Automatic chmod operations
- **Detailed Error Reporting**: Shows exact failure reasons and directory status

#### 2. **Improved View.php** (`view.php`)
- **Multi-Directory Support**: Searches all possible upload locations
- **Debug Information**: Shows directory status and available files
- **Better Error Messages**: Helps troubleshoot file access issues

#### 3. **Enhanced Dockerfile** 
- **777 Permissions**: Full read/write permissions for uploads
- **Fallback Directories**: Creates `/tmp/uploads` as backup
- **Runtime Permission Fixes**: Entrypoint script ensures correct permissions
- **Better PHP Configuration**: Improved upload settings

#### 4. **Additional Error Handling**
- **Detailed Upload Errors**: Specific error messages for each failure type
- **Permission Diagnostics**: Shows directory permissions and writability
- **File Validation**: Enhanced security checks

## 📋 What Changed:

### `index.php` - Main Changes:
```php
// OLD: Single directory
$uploadDir = 'uploads/';

// NEW: Multiple fallback directories
$uploadDirs = ['uploads/', './uploads/', '/tmp/uploads/'];
```

### `view.php` - Main Changes:
```php
// NEW: Multi-directory file search
foreach ($uploadDirs as $uploadDir) {
    if (is_dir($uploadDir)) {
        foreach ($possibleExtensions as $ext) {
            // Search logic...
        }
    }
}
```

### `Dockerfile` - Main Changes:
```dockerfile
# NEW: Better permissions and fallback directories
RUN mkdir -p uploads && chmod 777 uploads
RUN mkdir -p /tmp/uploads && chmod 777 /tmp/uploads && chown www-data:www-data /tmp/uploads

# NEW: Runtime permission fix
ENTRYPOINT ["/entrypoint.sh"]
```

## 🚀 Deployment Instructions:

1. **Copy all files** to remote server
2. **Build container**:
   ```bash
   docker-compose down
   docker-compose up --build -d
   ```
3. **Test upload functionality**
4. **Run exploit** to verify TOCTOU+LFI works

## ✅ Expected Results:

- **File uploads work** without permission errors
- **Debug information** helps troubleshoot any remaining issues
- **Multiple upload paths** provide redundancy
- **TOCTOU exploit** functions correctly

## 🔍 Troubleshooting:

If uploads still fail, check the debug output which now shows:
- Upload directory path used
- Directory permissions
- File existence status
- Detailed error messages

The improved version should resolve the remote server upload issues while maintaining the vulnerable TOCTOU+LFI functionality for the CTF challenge. 