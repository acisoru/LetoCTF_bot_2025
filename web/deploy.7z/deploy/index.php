<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPickMeUp - Image Upload Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .upload-form {
            border: 2px dashed #ccc;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
        }
        input[type="file"] {
            margin: 10px 0;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .file-info {
            margin: 20px 0;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🖼️ PHPickMeUp - Image Upload Service</h1>
        <p>Upload your images safely! We validate every image before processing.</p>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
            // Try multiple upload directory options for better compatibility
            $uploadDirs = ['uploads/', './uploads/', '/tmp/uploads/'];
            $uploadDir = '';
            
            // Find or create a writable upload directory
            foreach ($uploadDirs as $dir) {
                if (!is_dir($dir)) {
                    // Try to create directory with full permissions
                    if (@mkdir($dir, 0777, true)) {
                        @chmod($dir, 0777); // Ensure writable permissions
                        $uploadDir = $dir;
                        break;
                    }
                } else {
                    // Check if directory is writable
                    if (is_writable($dir)) {
                        $uploadDir = $dir;
                        break;
                    } else {
                        // Try to fix permissions
                        @chmod($dir, 0777);
                        if (is_writable($dir)) {
                            $uploadDir = $dir;
                            break;
                        }
                    }
                }
            }
            
            if (empty($uploadDir)) {
                echo '<div class="alert alert-error">Error: Cannot create or access upload directory. Server configuration issue.</div>';
            } else {
                $file = $_FILES['image'];
                $fileName = $file['name'];
                $fileTmp = $file['tmp_name'];
                $fileSize = $file['size'];
                $fileError = $file['error'];
                
                if ($fileError !== UPLOAD_ERR_OK) {
                    $errorMessages = [
                        UPLOAD_ERR_INI_SIZE => 'File too large (exceeds upload_max_filesize)',
                        UPLOAD_ERR_FORM_SIZE => 'File too large (exceeds MAX_FILE_SIZE)',
                        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                        UPLOAD_ERR_EXTENSION => 'File upload stopped by extension'
                    ];
                    $errorMsg = isset($errorMessages[$fileError]) ? $errorMessages[$fileError] : "Unknown error ($fileError)";
                    echo '<div class="alert alert-error">Upload failed: ' . $errorMsg . '</div>';
                } else {
                    // Check file extension
                    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    
                    if (!in_array($fileExtension, $allowedExtensions)) {
                        echo '<div class="alert alert-error">Only JPG, PNG, and GIF files are allowed!</div>';
                    } else {
                        // Generate unique filename
                        $uniqueId = uniqid('img_', true);
                        $newFileName = $uniqueId . '.' . $fileExtension;
                        $filePath = $uploadDir . $newFileName;
                        
                        // Additional checks before moving file
                        if (!is_uploaded_file($fileTmp)) {
                            echo '<div class="alert alert-error">Security error: Invalid uploaded file!</div>';
                        } else if (!is_writable($uploadDir)) {
                            echo '<div class="alert alert-error">Error: Upload directory is not writable! Directory: ' . htmlspecialchars($uploadDir) . '</div>';
                        } else {
                            // Move uploaded file
                            if (move_uploaded_file($fileTmp, $filePath)) {
                                // Set file permissions to ensure it's readable
                                @chmod($filePath, 0644);
                                
                                // VULNERABLE: Check if file is a valid image using getimagesize()
                                // This creates a TOCTOU vulnerability - time gap between check and use
                                echo '<div class="alert alert-success">File uploaded successfully! Validating image...</div>';
                                
                                // Artificial delay to make TOCTOU exploitation easier
                                sleep(1);
                                
                                $imageInfo = @getimagesize($filePath);
                                if ($imageInfo === false) {
                                    // Not a valid image, delete it
                                    @unlink($filePath);
                                    echo '<div class="alert alert-error">Invalid image file! File has been removed.</div>';
                                } else {
                                    // Valid image, show success message and preview link
                                    echo '<div class="alert alert-success">Image validated successfully!</div>';
                                    echo '<div class="file-info">';
                                    echo '<strong>File ID:</strong> ' . htmlspecialchars($uniqueId) . '<br>';
                                    echo '<strong>Type:</strong> ' . htmlspecialchars($imageInfo['mime']) . '<br>';
                                    echo '<strong>Dimensions:</strong> ' . $imageInfo[0] . 'x' . $imageInfo[1] . '<br>';
                                    echo '<strong>Upload Dir:</strong> ' . htmlspecialchars($uploadDir) . '<br>';
                                    echo '<br><a href="view.php?id=' . urlencode($uniqueId) . '" class="btn">👁️ View Image</a>';
                                    echo '</div>';
                                }
                            } else {
                                // Detailed error reporting for failed file move
                                $error = error_get_last();
                                echo '<div class="alert alert-error">Failed to save uploaded file!</div>';
                                echo '<div class="alert alert-error">Debug info:<br>';
                                echo 'Upload directory: ' . htmlspecialchars($uploadDir) . '<br>';
                                echo 'Target file: ' . htmlspecialchars($filePath) . '<br>';
                                echo 'Temp file exists: ' . (file_exists($fileTmp) ? 'Yes' : 'No') . '<br>';
                                echo 'Directory writable: ' . (is_writable($uploadDir) ? 'Yes' : 'No') . '<br>';
                                echo 'Directory permissions: ' . substr(sprintf('%o', fileperms($uploadDir)), -4) . '<br>';
                                if ($error) {
                                    echo 'Last error: ' . htmlspecialchars($error['message']) . '<br>';
                                }
                                echo '</div>';
                            }
                        }
                    }
                }
            }
        }
        ?>
        
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <h3>📎 Upload Your Image</h3>
            <p>Supported formats: JPG, PNG, GIF</p>
            <input type="file" name="image" accept="image/*" required>
            <br><br>
            <button type="submit" class="btn">🚀 Upload Image</button>
        </form>
        
        <div class="file-info">
            <h4>ℹ️ How it works:</h4>
            <ol>
                <li>Upload an image file (JPG, PNG, or GIF)</li>
                <li>Server validates the file using <code>getimagesize()</code></li>
                <li>Valid images are stored and can be viewed</li>
                <li>Invalid files are automatically deleted</li>
            </ol>
        </div>
    </div>
</body>
</html> 