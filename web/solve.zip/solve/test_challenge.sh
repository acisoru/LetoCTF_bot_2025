#!/bin/bash

# PHPickMeUp CTF Challenge Test Script
# Tests various aspects of the challenge to ensure it works correctly

set -e

TARGET_URL="http://localhost:8080"
BOLD='\033[1m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BOLD}PHPickMeUp CTF Challenge Test Suite${NC}"
echo "=============================================="
echo "Testing PHP 7.4 + Nginx + Docker configuration"

# Function to print test results
print_result() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}[PASS]${NC} $2"
    else
        echo -e "${RED}[FAIL]${NC} $2"
    fi
}

# Test 1: Check if the service is running
echo -e "\n${YELLOW}Test 1: Service Availability${NC}"
if curl -s --connect-timeout 5 "$TARGET_URL" > /dev/null; then
    print_result 0 "Service is accessible"
else
    print_result 1 "Service is not accessible"
    echo "Make sure to run: docker run -d -p 8080:80 phpickmeup"
    exit 1
fi

# Test 2: Check main page loads correctly
echo -e "\n${YELLOW}Test 2: Main Page Content${NC}"
response=$(curl -s "$TARGET_URL")
if echo "$response" | grep -q "PHPickMeUp - Image Upload Service"; then
    print_result 0 "Main page loads correctly"
else
    print_result 1 "Main page does not load correctly"
fi

# Test 3: Check upload form exists
if echo "$response" | grep -q 'name="image"'; then
    print_result 0 "Upload form is present"
else
    print_result 1 "Upload form is missing"
fi

# Test 4: Check flag file protection
echo -e "\n${YELLOW}Test 3: Flag Protection${NC}"
flag_response=$(curl -s -w "%{http_code}" "$TARGET_URL/flag.txt" -o /dev/null)
if [ "$flag_response" = "403" ] || [ "$flag_response" = "404" ]; then
    print_result 0 "Flag file is protected (HTTP $flag_response)"
else
    print_result 1 "Flag file is accessible directly (HTTP $flag_response)"
fi

# Test 4.5: Check nginx configuration files protection
echo -e "\n${YELLOW}Test 3.5: Config Files Protection${NC}"
nginx_response=$(curl -s -w "%{http_code}" "$TARGET_URL/nginx.conf" -o /dev/null)
if [ "$nginx_response" = "403" ] || [ "$nginx_response" = "404" ]; then
    print_result 0 "Nginx config file is protected (HTTP $nginx_response)"
else
    print_result 1 "Nginx config file is accessible directly (HTTP $nginx_response)"
fi

# Test 5: Create a test image file
echo -e "\n${YELLOW}Test 4: File Upload Functionality${NC}"
test_image="/tmp/test_image.jpg"

# Create minimal JPEG file
cat > "$test_image" << 'EOF'
����JFIF  H H  ��C 


		
%# , #&')*)-0-(0%()(��C



(((((((((((((((((((((((((((((((((((((((((((((((((((��   " ��           	
�� �   } !1AQa"q2���#B��R��$3br�	
%&'()*456789:CDEFGHIJSTUVWXYZcdefghijstuvwxyz���������������������������������������������������������������������������        	
�� �  w !1AQaq"2�B����	#3R�br�
$4�%�&'()*56789:CDEFGHIJSTUVWXYZcdefghijstuvwxyz��������������������������������������������������������������������������   ? ��
EOF

# Convert to binary (this creates a minimal valid JPEG)
printf '\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $.\x27 ",#\x1c\x1c(7),01444\x1f\x279=82<.342\xff\xc0\x00\x11\x08\x00\x01\x00\x01\x01\x01\x11\x00\x02\x11\x01\x03\x11\x01\xff\xc4\x00\x14\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\xff\xc4\x00\x14\x10\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xda\x00\x0c\x03\x01\x00\x02\x11\x03\x11\x00\x3f\x00\xaa\xff\xd9' > "$test_image"

# Test upload
upload_response=$(curl -s -X POST -F "image=@$test_image" "$TARGET_URL/index.php")
if echo "$upload_response" | grep -q "Image validated successfully"; then
    print_result 0 "Valid image upload works"
    
    # Extract file ID for further testing
    file_id=$(echo "$upload_response" | grep -o 'File ID:</strong>[^<]*' | sed 's/File ID:<\/strong> *//')
    if [ -n "$file_id" ]; then
        print_result 0 "File ID extraction works: $file_id"
        
        # Test view page
        view_response=$(curl -s "$TARGET_URL/view.php?id=$file_id")
        if echo "$view_response" | grep -q "Image Viewer"; then
            print_result 0 "View page works"
        else
            print_result 1 "View page does not work"
        fi
    else
        print_result 1 "Could not extract file ID from upload response"
    fi
else
    print_result 1 "Valid image upload failed"
    echo "Upload response: $upload_response"
fi

# Test 6: Test invalid file upload
echo -e "\n${YELLOW}Test 5: Invalid File Rejection${NC}"
echo "Not a real image" > /tmp/fake_image.txt
invalid_response=$(curl -s -X POST -F "image=@/tmp/fake_image.txt" "$TARGET_URL/index.php")
if echo "$invalid_response" | grep -q "Only JPG, PNG, and GIF files are allowed"; then
    print_result 0 "Invalid file extension rejection works"
else
    print_result 1 "Invalid file extension rejection failed"
fi

# Test 7: Test uploads directory
echo -e "\n${YELLOW}Test 6: Uploads Directory${NC}"
uploads_response=$(curl -s -w "%{http_code}" "$TARGET_URL/uploads/" -o /dev/null)
if [ "$uploads_response" = "403" ]; then
    print_result 0 "Uploads directory listing is blocked"
else
    print_result 1 "Uploads directory listing is not properly blocked (HTTP $uploads_response)"
fi

# Test 8: Test TOCTOU exploitation (if Python is available)
echo -e "\n${YELLOW}Test 7: TOCTOU Vulnerability Test${NC}"
if command -v python3 > /dev/null 2>&1; then
    if [ -f "exploit.py" ]; then
        echo "Running exploit script..."
        if python3 exploit.py "$TARGET_URL" 2>/dev/null; then
            print_result 0 "TOCTOU exploitation successful"
        else
            print_result 1 "TOCTOU exploitation failed (this might be expected in containerized environment)"
            echo "Note: Exploit might require local file system access to work properly"
        fi
    else
        print_result 1 "Exploit script not found"
    fi
else
    echo "Python3 not available, skipping exploit test"
fi

# Clean up
rm -f "$test_image" /tmp/fake_image.txt

echo -e "\n${BOLD}Test Summary${NC}"
echo "=============================================="
echo "Challenge should be ready for CTF participants!"
echo ""
echo "Manual testing steps:"
echo "1. Visit http://localhost:8080"
echo "2. Upload a valid image file"
echo "3. During the 1-second validation delay, replace the file with PHP code"
echo "4. Access the view page to trigger LFI"
echo "5. Retrieve the flag: flag{race_condition_file_inclusion_1337}"
echo ""
echo "For automated exploitation, run: python3 exploit.py" 